$(document).ready(function(){
    $('.burgermenu').on('click', function(){
        $('.mobile-nav').slideToggle();
    })
});